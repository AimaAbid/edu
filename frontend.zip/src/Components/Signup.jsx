import React from 'react'

import Signupstudent from "./Register/Signupstudent"
// import Header from './Header';


export default function Signup() {
  return (
    <div>
      {/*  we have a dialogue box in navbar when we click on sign up and then we can use 2 signup options as student and expert for now i have put both here*/}
     {/* <Signupexpert/> */}
     <Signupstudent/>
      
      
      
      
   
    
    </div>
  )
}
