import React from 'react'

export default function UploadedCourses() {
  return (
    <div>UploadedCourses</div>
  )
}
