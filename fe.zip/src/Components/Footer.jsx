import React from 'react'

export default function Footer() {
  return (
    <div className='footer'>Made with React 2024 </div>
  )
}
