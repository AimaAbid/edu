import React, { useState } from "react";
import { Link } from "react-router-dom";
import "./Course.css";
import Footer from "../Footer";
import icon1 from "../../Assets/icon1.png";
import iconThree from "../../Assets/icon1of3.png";
export default function Course() {
	const [sidebarActive, setSidebarActive] = useState(false);

	const toggleSidebar = () => {
		setSidebarActive(!sidebarActive);
	};

	return (
		<div className="course-container">
			<div className="course-header">
				<div className="header-items">EduCollabHub</div>
				<div className="header-items">Introduction to Cyber Security</div>
				<div className="header-items" onClick={toggleSidebar}>
					Course Outline
				</div>
			</div>

			<div className={`course-sidebar ${sidebarActive ? "active" : ""}`}>
				<h2>Course Outline</h2>
				<ul>
					<li>
						<Link to="/">Knowledge Check</Link>
					</li>
					<li>
						<Link to="/">Module 1: Basics</Link>
						<ul>
							<li>
								<Link to="/">Submodule 1.1: Introduction</Link>
							</li>
							<li>
								<Link to="/">Submodule 1.2: Overview</Link>
							</li>
						</ul>
					</li>
					<li>
						<Link to="/">Module 2: Intermediate</Link>
						<ul>
							<li>
								<Link to="/">Submodule 2.1: Concepts</Link>
							</li>
							<li>
								<Link to="/">Submodule 2.2: Applications</Link>
							</li>
						</ul>
					</li>
					<li>
						<Link to="/">Module 3: Advanced</Link>
						<ul>
							<li>
								<Link to="/">Submodule 3.1: Techniques</Link>
							</li>
							<li>
								<Link to="/">Submodule 3.2: Implementations</Link>
							</li>
						</ul>
					</li>
					<li>
						<Link to="/">Module 4: Expert</Link>
						<ul>
							<li>
								<Link to="/">Submodule 4.1: Case Studies</Link>
							</li>
							<li>
								<Link to="/">Submodule 4.2: Projects</Link>
							</li>
						</ul>
					</li>
				</ul>
			</div>

			<div className={`course-content ${sidebarActive ? "active" : ""}`}>
				<section></section>

				<section className="s0">
					<div className="heading">
						<div>
							<p>1.1 Welcome to the world of Cyber Security</p>
						</div>
					</div>
				</section>
				<section className="s1">
					<div className="s1-container">
						<div className="img">
							<img src={icon1} alt="i" />
						</div>
						<div className="text-refine">
							<p>
								Hi, my name is Guru. Welcome to eLearning company @Apollo. We’re
								delighted to have you on board. The company is in a critical
								growth phase, but we’re worried that we’re susceptible to
								security breaches.
							</p>

							<br />
							<p>
								We’ve seen so many companies fall victim to cybercrime, and we
								don’t want to be next. We need to move quickly and build our
								cybersecurity defenses. Are you ready to help?
							</p>
						</div>
					</div>
				</section>

				<section className="s2">
					<div className="s2-container">
						<div className="text-container">
							<div className="heading1">
								<p>1.1.1 What Is Cybersecurity?</p>
							</div>

							<div className="normal-text">
								<p>
									Cybersecurity is the ongoing effort to protect individuals,
									organizations and governments from digital attacks by
									protecting networked systems and data from unauthorized use or
									harm.
								</p>
							</div>

							<div className="image">
								<img src={iconThree} alt="i" />
							</div>
							<div className="card-container">
								<div className="my-card">
									<p>
										<b>Personal</b>
									</p>
									<p>
										On a personal level, you need to safeguard your identity,
										your data, and your computing devices.
									</p>
								</div>
								<div className="my-card">
									<p>
										<b>Organizational</b>
									</p>
									<p>
										At an organizational level, it is everyone’s responsibility
										to protect the organization’s reputation, data and
										customers.
									</p>
								</div>
								<div className="my-card">
									<p>
										<b>Government</b>
									</p>
									<p>
										As more digital information is being gathered and shared,
										its protection becomes even more vital at the government
										level, where national security, economic stability and the
										safety and wellbeing of citizens are at stake.
									</p>
								</div>
							</div>
						</div>
					</div>
				</section>

				{/* <section className="s3">
					
						<div className="s3-container">
						<div className="text-container">
						<div className="heading1">
								{/* <p>1.1.2 Protecting Your Personal Data</p> */}
							{/* </div>
							</div>

						</div>
					
				</section> */} 

				<div className="lala">
					<p>ndjkskjs</p>
				</div>

		
			</div>
		</div>
	);
}
