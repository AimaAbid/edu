import React from 'react'

export default function CreateCourses() {
  return (
    <div>CreateCourses</div>
  )
}
