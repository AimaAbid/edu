import React from 'react'
// import CheckoutForm from '../CheckOutForm'
// import Alumni from '../Components/Register/Alumni'
import AlumniLogin from '../Components/Register/AlumniLogin'

export default function AlumniAbout() {
  return (
    <div>
      <AlumniLogin/>
     
    </div>
  )
}
